#!/bin/sh

# Daily self-healing check. It must never break ordinary WAN internet.
# It only restarts local services and reapplies the separate vpn table.

LOG_TAG="RouteWolf-healthcheck"
log() { logger -t "$LOG_TAG" "$*" 2>/dev/null || echo "$LOG_TAG: $*"; }

[ -f /etc/routewolf/route.conf ] && . /etc/routewolf/route.conf
[ -f /etc/routewolf/user.conf ] && . /etc/routewolf/user.conf

# Sing-box safety: if sbtun0 is selected but sing-box is stopped, try to restart it.
# If it still does not create sbtun0, routewolf-route.sh will keep table vpn empty
# and normal WAN internet will continue to work.
if [ "$VPN_ROUTE_DEV" = "sbtun0" ]; then
    if ! pidof sing-box >/dev/null 2>&1 || ! ip link show sbtun0 >/dev/null 2>&1; then
        log "sing-box missing or sbtun0 missing; restarting sing-box"
        /etc/init.d/sing-box restart >/dev/null 2>&1 || true
        sleep 5
    fi
fi

# Remove stale fail-closed leftovers from old builds.
ip route del blackhole default table vpn metric 42767 >/dev/null 2>&1 || true
ip -6 route del blackhole default table vpn metric 42767 >/dev/null 2>&1 || true

# If OpenVPN is selected, never allow server-pushed full-tunnel /1 routes to remain in main table.
case "$VPN_ROUTE_DEV" in
    tun*)
        ip route show 2>/dev/null | grep -E "^(0\.0\.0\.0/1|128\.0\.0\.0/1).* dev ${VPN_ROUTE_DEV}( |$)" | while IFS= read -r route_line; do
            ip route del $route_line >/dev/null 2>&1 || true
        done
    ;;
esac

# Make sure only the helper owns the vpn table.
ip route flush table vpn >/dev/null 2>&1 || true
/usr/sbin/routewolf-route.sh >/dev/null 2>&1 || true

# Keep healthcheck light for weak routers: do not download lists here.
# Daily list refresh is handled by cron /etc/init.d/routewolf start.
# Restart dnsmasq only if its syntax test fails or working lists are missing.
if ! dnsmasq --test >/dev/null 2>&1; then
    log "dnsmasq test failed; restarting dnsmasq"
    /etc/init.d/dnsmasq restart >/dev/null 2>&1 || true
elif [ ! -s /tmp/dnsmasq.d/domains.lst ]; then
    log "domain list missing; refreshing lists and restarting dnsmasq"
    /etc/init.d/routewolf start >/dev/null 2>&1 || true
    /etc/init.d/dnsmasq restart >/dev/null 2>&1 || true
fi

# Reapply route after possible service changes.
/usr/sbin/routewolf-route.sh >/dev/null 2>&1 || true

# Run the universal tunnel watchdog. It restarts only the selected tunnel and keeps WAN fail-open.
if [ -x /usr/sbin/routewolf-watchdog.sh ]; then
    /usr/sbin/routewolf-watchdog.sh check >/dev/null 2>&1 || true
fi

# Basic AWG/WG visibility log; no blocking actions.
if [ -n "$VPN_ROUTE_DEV" ] && ip link show "$VPN_ROUTE_DEV" >/dev/null 2>&1; then
    log "ok: $VPN_ROUTE_DEV exists; vpn table: $(ip route show table vpn 2>/dev/null | tr '\n' ' ')"
else
    log "vpn interface missing/down; fail-open keeps WAN unaffected"
fi
