#!/bin/sh
# Clear stale temporary DNS/nft state and re-apply RouteWolf. Does not delete saved user config.
set +e
echo "Purging RouteWolf runtime state..."
rm -f /tmp/dnsmasq.d/domains.lst /tmp/dnsmasq.d/domains.lst.new /tmp/dnsmasq.d/domains.raw       /tmp/lst/ipv4.lst /tmp/lst/ipv4.lst.new /tmp/lst/ipv4.raw       /tmp/lst/ipv6.lst /tmp/lst/ipv6.lst.new /tmp/lst/ipv6.raw 2>/dev/null || true
for set in vpn_domains vpn_subnets vpn_domains6 vpn_subnets6; do
    nft flush set inet fw4 "$set" >/dev/null 2>&1 || true
done
/etc/init.d/dnsmasq stop >/dev/null 2>&1 || true
/etc/init.d/firewall restart >/dev/null 2>&1 || true
/etc/init.d/dnsmasq start >/dev/null 2>&1 || true
/usr/sbin/routewolf-apply.sh /tmp/routewolf-purge-apply.log
