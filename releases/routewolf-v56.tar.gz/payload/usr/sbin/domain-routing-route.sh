#!/bin/sh
exec /usr/sbin/routewolf-route.sh "$@"
