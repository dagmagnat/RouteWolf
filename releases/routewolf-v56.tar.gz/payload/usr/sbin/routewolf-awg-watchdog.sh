#!/bin/sh
# Compatibility alias for older RouteWolf commands.
exec /usr/sbin/routewolf-watchdog.sh "$@"
