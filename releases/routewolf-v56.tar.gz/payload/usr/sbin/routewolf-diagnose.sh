#!/bin/sh

# RouteWolf diagnostics. This command does not change ordinary WAN routing.
# It prints enough information to paste into an issue/chat for troubleshooting.

RED='\033[31;1m'; GREEN='\033[32;1m'; YELLOW='\033[33;1m'; BLUE='\033[34;1m'; RESET='\033[0m'
ok() { printf "%bOK%b: %s\n" "$GREEN" "$RESET" "$*"; }
warn() { printf "%bWARN%b: %s\n" "$YELLOW" "$RESET" "$*"; }
bad() { printf "%bERROR%b: %s\n" "$RED" "$RESET" "$*"; }
section() { printf "\n%b=== %s ===%b\n" "$BLUE" "$1" "$RESET"; }

[ -f /etc/routewolf/route.conf ] && . /etc/routewolf/route.conf
[ -f /etc/routewolf/user.conf ] && . /etc/routewolf/user.conf

section "RouteWolf diagnostics"
echo "Version: v44-low-flash-safe"
echo "Date: $(date 2>/dev/null)"
echo "Model: $(ubus call system board 2>/dev/null | jsonfilter -e '@.model' 2>/dev/null || cat /tmp/sysinfo/model 2>/dev/null)"
echo "OpenWrt: $(ubus call system board 2>/dev/null | jsonfilter -e '@.release.description' 2>/dev/null)"

section "Detected tunnel"
DETECTED=""
DEV="${VPN_ROUTE_DEV:-}"
if [ -z "$DEV" ] && [ "$(uci -q get network.awg0.proto 2>/dev/null)" = "amneziawg" ]; then DEV="awg0"; fi
if [ -z "$DEV" ] && [ "$(uci -q get network.wg0.proto 2>/dev/null)" = "wireguard" ]; then DEV="wg0"; fi
if [ -z "$DEV" ] && ip link show sbtun0 >/dev/null 2>&1; then DEV="sbtun0"; fi
if [ -z "$DEV" ]; then DEV=$(ip -o link show 2>/dev/null | awk -F': ' '$2 ~ /^tun[0-9]/ {print $2; exit}'); fi
VPN_ROUTE_DEV="$DEV"

case "$DEV" in
    awg0) DETECTED="AmneziaWG" ;;
    wg0) DETECTED="WireGuard" ;;
    sbtun0) DETECTED="Sing-box" ;;
    tun*) DETECTED="OpenVPN" ;;
    *) DETECTED="unknown" ;;
esac

echo "Detected type: $DETECTED"
echo "Route device: ${DEV:-not found}"
[ -n "$DEV" ] && ip addr show dev "$DEV" 2>/dev/null || warn "VPN route device not found"

case "$DEV" in
    awg0)
        if command -v awg >/dev/null 2>&1; then
            awg show 2>/dev/null | grep -E 'interface:|peer:|endpoint|latest handshake|transfer|allowed ips' || true
            awg show 2>/dev/null | grep -q 'latest handshake' && ok "AmneziaWG has handshake" || warn "No AmneziaWG handshake shown"
        else
            bad "awg command not found"
        fi
        ;;
    wg0)
        if command -v wg >/dev/null 2>&1; then
            wg show 2>/dev/null | grep -E 'interface:|peer:|endpoint|latest handshake|transfer|allowed ips' || true
            wg show 2>/dev/null | grep -q 'latest handshake' && ok "WireGuard has handshake" || warn "No WireGuard handshake shown"
        else
            bad "wg command not found"
        fi
        ;;
    sbtun0)
        pidof sing-box >/dev/null 2>&1 && ok "sing-box process is running" || bad "sing-box process is not running"
        command -v sing-box >/dev/null 2>&1 && sing-box version 2>/dev/null | head -n 2 || true
        [ -f /etc/sing-box/config.json ] && sing-box check -c /etc/sing-box/config.json 2>/tmp/routewolf-singbox-check.log && ok "sing-box config check OK" || warn "sing-box config check failed or config missing; see /tmp/routewolf-singbox-check.log"
        ;;
    tun*)
        pidof openvpn >/dev/null 2>&1 && ok "OpenVPN process is running" || warn "OpenVPN process is not running"
        uci show openvpn 2>/dev/null | sed -n '1,20p'
        ;;
esac

LAN_IP="$(uci -q get network.lan.ipaddr 2>/dev/null)"
[ -n "$LAN_IP" ] || LAN_IP="192.168.1.1"

section "Normal WAN internet"
ip route show default 2>/dev/null || true
case "$DEV" in
    tun*)
        if ip route show 2>/dev/null | grep -E "^(0\.0\.0\.0/1|128\.0\.0\.0/1).* dev ${DEV}( |$)" >/dev/null; then
            bad "OpenVPN full-tunnel /1 routes found in main table. Add route-nopull/pull-filter or run /usr/sbin/routewolf-route.sh"
        else
            ok "No OpenVPN full-tunnel /1 routes in main table"
        fi
    ;;
esac
if ping -c 2 -W 2 1.1.1.1 >/tmp/routewolf-ping.log 2>&1; then ok "Ping 1.1.1.1 works"; else bad "Ping 1.1.1.1 failed"; cat /tmp/routewolf-ping.log; fi
if nslookup openwrt.org "$LAN_IP" >/tmp/routewolf-nslookup-wan.log 2>&1; then ok "Router DNS works through $LAN_IP"; else bad "Router DNS failed through $LAN_IP"; cat /tmp/routewolf-nslookup-wan.log; fi

section "Router resources"
uptime 2>/dev/null || true
free -m 2>/dev/null || free 2>/dev/null || true
df -h / /tmp 2>/dev/null || df -h / 2>/dev/null || true
echo "Load command: /usr/sbin/routewolf-load.sh"

section "Lists and dnsmasq"
ls -lah /tmp/dnsmasq.d/domains.lst /tmp/lst/ipv4.lst /tmp/lst/ipv6.lst 2>/dev/null || true
if [ -s /tmp/dnsmasq.d/domains.lst ]; then
    DOM_LINES=$(wc -l < /tmp/dnsmasq.d/domains.lst)
    [ "$DOM_LINES" -ge 5 ] && ok "Domain list exists: $DOM_LINES lines" || bad "Domain list is too small: $DOM_LINES lines. Run /etc/init.d/routewolf start and check GitHub raw list."
else
    bad "Domain list is missing or empty"
fi
if [ -s /tmp/lst/ipv4.lst ]; then
    IPV4_LINES=$(wc -l < /tmp/lst/ipv4.lst)
    [ "$IPV4_LINES" -ge 5 ] && ok "IPv4 CIDR list exists: $IPV4_LINES lines" || bad "IPv4 CIDR list is too small: $IPV4_LINES lines"
    grep -q '^203\.0\.113\.0/24$' /tmp/lst/ipv4.lst 2>/dev/null && bad "IPv4 list contains example TEST-NET 203.0.113.0/24. Replace it with real GitHub list."
else
    warn "IPv4 CIDR list is missing or empty"
fi
if dnsmasq --test >/tmp/routewolf-dnsmasq-test.log 2>&1; then ok "dnsmasq syntax OK"; else bad "dnsmasq test failed"; cat /tmp/routewolf-dnsmasq-test.log; fi
uci show dhcp 2>/dev/null | grep -E "dnsmasq.d|filter_aaaa" || true

section "Policy routing"
if [ -x /etc/init.d/routewolf-route ] && [ -x /usr/sbin/routewolf-route.sh ]; then
    ok "Policy rule persistence is provided by RouteWolf init/hotplug"
else
    bad "RouteWolf route restore service is missing; run: rw repair"
fi
ip rule show 2>/dev/null | grep -Eq '^100:.*fwmark 0x1(/0x1)?.*lookup (vpn|99)' &&     ok "Runtime fwmark rule is present at priority 100" || bad "Runtime fwmark rule is missing or has a stale priority"
ip rule show 2>/dev/null | grep -E 'fwmark 0x1|lookup vpn' || true
VPN_TABLE=$(ip route show table vpn 2>/dev/null)
printf '%s\n' "$VPN_TABLE"
echo "$VPN_TABLE" | grep -q 'blackhole' && bad "blackhole route found in table vpn; old broken fail-closed route must be removed"
if [ -n "$DEV" ] && ip link show dev "$DEV" 2>/dev/null | grep -q 'UP'; then
    echo "$VPN_TABLE" | grep -q "dev $DEV" && ok "table vpn routes marked traffic to $DEV" || bad "table vpn does not route to $DEV"
else
    [ -z "$VPN_TABLE" ] && ok "VPN device is down/missing and table vpn is empty: fail-open OK" || warn "VPN device is down/missing but table vpn is not empty"
fi

section "Firewall/nft marks"
nft list ruleset 2>/tmp/routewolf-nft.err | grep -E 'vpn_domains|vpn_subnets|mark_domains|mark_subnet|routewolf_force_dns' -n || warn "No RouteWolf nft/firewall rules shown"
if nft list set inet fw4 vpn_domains >/tmp/routewolf-vpn-domains-set 2>/dev/null; then
    ok "nft set vpn_domains exists"
    head -n 40 /tmp/routewolf-vpn-domains-set
else
    bad "nft set vpn_domains does not exist"
fi
if nft list set inet fw4 vpn_subnets >/tmp/routewolf-vpn-subnets-set 2>/dev/null; then
    ok "nft set vpn_subnets exists"
    head -n 20 /tmp/routewolf-vpn-subnets-set
else
    warn "nft set vpn_subnets does not exist or IPv4 CIDR list was not applied"
fi

section "YouTube route test"
YOUTUBE_IP=$(nslookup youtube.com "$LAN_IP" 2>/tmp/routewolf-youtube-nslookup.log | awk '/^Address: / && $2 ~ /^[0-9.]+$/ {print $2; exit}')
if [ -n "$YOUTUBE_IP" ]; then
    ok "youtube.com resolved by router to $YOUTUBE_IP"
    nft list set inet fw4 vpn_domains 2>/dev/null | grep -q "$YOUTUBE_IP" && ok "youtube.com IP is in vpn_domains" || warn "youtube.com IP is not visible in vpn_domains yet"
    echo "table vpn route for marked traffic:"
    ip route show table vpn 2>/dev/null || true
    if ip route show table vpn 2>/dev/null | grep -q "dev ${DEV}"; then
        ok "marked traffic uses table vpn through $DEV"
    else
        warn "table vpn does not show $DEV for marked traffic"
    fi
else
    bad "Could not resolve youtube.com through router DNS ($LAN_IP)"
    cat /tmp/routewolf-youtube-nslookup.log 2>/dev/null
fi

section "Android TV / YouTube DNS path"
if uci show firewall 2>/dev/null | grep -q "name='routewolf_force_dns'"; then
    ok "LAN DNS interception is enabled; ordinary TCP/UDP DNS is forced through router dnsmasq"
else
    warn "LAN DNS interception is disabled. Android TV or another client with hardcoded DNS may bypass dnsmasq and miss vpn_domains. Optional fix: rw dns on"
fi
check_tv_domain() {
    host="$1"
    ip="$(nslookup "$host" "$LAN_IP" 2>/dev/null | awk '/^Address: / && $2 ~ /^[0-9.]+$/ {print $2; exit}')"
    if [ -z "$ip" ]; then
        warn "$host did not resolve through router DNS"
        return
    fi
    if nft list set inet fw4 vpn_domains 2>/dev/null | grep -Fq "$ip"; then
        ok "$host -> $ip is present in vpn_domains"
    else
        warn "$host -> $ip is not visible in vpn_domains yet"
    fi
}
check_tv_domain www.youtube.com
check_tv_domain youtubei.googleapis.com
check_tv_domain i.ytimg.com
check_tv_domain redirector.googlevideo.com

section "LAN / Wi-Fi notes"
echo "LAN IP: $LAN_IP"
echo "LAN device: $(uci -q get network.lan.device 2>/dev/null)"
echo "Firewall LAN zone:"
uci show firewall 2>/dev/null | grep -E "zone.*name='lan'|network='lan'|network=.*lan" | head -n 20
MARK_LINES=$(nft list ruleset 2>/dev/null | grep -E 'mark_domains|mark_subnet' || true)
echo "$MARK_LINES"
echo "$MARK_LINES" | grep -q 'packets 0' && warn "Mark counters include 0 packets. Open YouTube from a LAN client and run diagnostics again. If still 0, client may use Private DNS/DoH or not pass through LAN zone."

section "Recommended repair commands"
echo "Update lists:          /etc/init.d/routewolf start"
echo "Repair route:          /usr/sbin/routewolf-route.sh"
echo "Restart firewall/DNS:  /etc/init.d/firewall restart; /etc/init.d/dnsmasq restart"
echo "Full status:           /usr/sbin/routewolf-status.sh"
echo "Paste this whole diagnostics output when asking for help."
