#!/bin/sh
exec /usr/sbin/routewolf-status.sh "$@"
