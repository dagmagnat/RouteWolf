#!/bin/sh
LOG="${1:-/tmp/routewolf-apply.log}"
if /etc/init.d/routewolf start >"$LOG" 2>&1; then rc=0; else rc=$?; fi
tail -n 40 "$LOG" 2>/dev/null || true
exit "$rc"
