#!/bin/sh
# Remove RouteWolf rules, lists, cron and helper scripts.
set -e
cd /tmp
/usr/sbin/routewolf-fetch.sh https://raw.githubusercontent.com/dagmagnat/RouteWolf/main/uninstall.sh /tmp/routewolf-uninstall.sh
exec sh /tmp/routewolf-uninstall.sh "$@"
