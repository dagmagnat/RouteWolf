#!/bin/sh

[ ! -f /etc/routewolf/route.conf ] && [ -f /etc/domain-routing-route.conf ] && { mkdir -p /etc/routewolf; cp /etc/domain-routing-route.conf /etc/routewolf/route.conf 2>/dev/null || true; }
[ ! -f /etc/routewolf/user.conf ] && [ -f /etc/domain-routing-user.conf ] && { mkdir -p /etc/routewolf; cp /etc/domain-routing-user.conf /etc/routewolf/user.conf 2>/dev/null || true; }
[ -f /etc/routewolf/route.conf ] && . /etc/routewolf/route.conf
[ -f /etc/routewolf/user.conf ] && . /etc/routewolf/user.conf

echo "=== RouteWolf v41 status ==="
echo "VPN_ROUTE_DEV=${VPN_ROUTE_DEV:-not set}"
echo "VPN_ROUTE_GW=${VPN_ROUTE_GW:-not set}"
echo "IPV6_SUPPORT=${IPV6_SUPPORT:-0}"
echo "DOMAINS_URL=${DOMAINS_URL:-not set}"
echo "IPV4_URL=${IPV4_URL:-not set}"
echo ""
echo "=== main default route, unaffected by this project ==="
ip route show default 2>/dev/null || true
echo ""
echo "=== vpn policy route ==="
ip rule show 2>/dev/null | grep -E "fwmark 0x1|lookup vpn" || true
ip route show table vpn 2>/dev/null || true
echo ""
echo "=== vpn interface ==="
[ -n "$VPN_ROUTE_DEV" ] && ip addr show dev "$VPN_ROUTE_DEV" 2>/dev/null || echo "No VPN route device configured"
echo ""
echo "=== lists ==="
ls -lah /tmp/dnsmasq.d/domains.lst /tmp/lst/ipv4.lst /tmp/lst/ipv6.lst 2>/dev/null || true
echo ""
echo "=== firewall DNS redirect ==="
uci show firewall 2>/dev/null | grep -E "routewolf_force_dns|src_dport='53'|dest_port='53'|dest_ip" || true
echo ""
echo "=== firewall marks ==="
nft list ruleset 2>/dev/null | grep -E "vpn_domains|vpn_subnets|mark_domains|mark_subnet" -n || true
echo ""
echo "=== quick checks ==="
echo "If table vpn shows blackhole default, it is stale from older builds: run /usr/sbin/routewolf-route.sh."
echo "If mark counters stay at 0 while opening a site from LAN, the client is probably using DoH/Private DNS/cache or not going through br-lan."
