#!/bin/sh
# YouTube/Smart TV diagnostics. Usage: routewolf-youtube.sh [TV_IP]
TV_IP="$1"
LAN_IP="$(uci -q get network.lan.ipaddr 2>/dev/null)"; [ -n "$LAN_IP" ] || LAN_IP="192.168.1.1"
echo "=== RouteWolf YouTube/TV diagnostics ==="
echo "LAN DNS: $LAN_IP"
[ -n "$TV_IP" ] && echo "TV/STB IP: $TV_IP" || echo "TV/STB IP: not provided"
echo
if [ -n "$TV_IP" ]; then
    echo "--- route from TV to common IPs ---"
    ip route get 8.8.8.8 from "$TV_IP" 2>/dev/null || true
    ip route get 1.1.1.1 from "$TV_IP" 2>/dev/null || true
    echo
fi
echo "--- DNS/domain checks ---"
for d in youtube.com www.youtube.com tv.youtube.com youtubei.googleapis.com androidtvwatsonfe-pa.googleapis.com i.ytimg.com yt3.ggpht.com redirector.googlevideo.com manifest.googlevideo.com googlevideo.com gvt1.com; do
    ip="$(nslookup "$d" "$LAN_IP" 2>/dev/null | awk '/^Address: / && $2 ~ /^[0-9.]+$/ {print $2; exit}')"
    printf '%-45s %s
' "$d" "${ip:-NO_A_RECORD}"
    if [ -n "$ip" ]; then
        nft list set inet fw4 vpn_domains 2>/dev/null | grep -Fq "$ip" && echo "  OK: $ip is in vpn_domains" || echo "  WARN: $ip is not visible in vpn_domains yet"
        ip route get "$ip" 2>/dev/null | sed 's/^/  router route: /'
    fi
done
echo
echo "--- IPv6 / AAAA mode ---"
uci -q get dhcp.@dnsmasq[0].filter_aaaa 2>/dev/null | awk '{print "filter_aaaa=" $0}' || echo "filter_aaaa is not set"
nslookup youtube.com "$LAN_IP" 2>/dev/null | grep -E 'Address: .*:' >/dev/null && echo "WARN: AAAA answers are visible" || echo "OK/unknown: no AAAA shown by this nslookup"
echo

echo "--- VPN MTU ---"
[ -f /etc/routewolf/route.conf ] && . /etc/routewolf/route.conf 2>/dev/null || true
[ -n "$VPN_ROUTE_DEV" ] && echo "VPN_ROUTE_DEV=$VPN_ROUTE_DEV VPN_ROUTE_MTU=${VPN_ROUTE_MTU:-unset}"
[ -n "$VPN_ROUTE_DEV" ] && ip link show dev "$VPN_ROUTE_DEV" 2>/dev/null | awk '/mtu/ {for(i=1;i<=NF;i++) if($i=="mtu") print "runtime_mtu="$(i+1)}'
for d in wg0 awg0; do uci -q get network.$d.mtu 2>/dev/null | awk -v dev="$d" '{print dev" uci_mtu="$0}'; done
echo
echo "--- DNS interception ---"
uci show firewall 2>/dev/null | grep -A10 -B1 "name='routewolf_force_dns'" || echo "DNS interception is OFF. Try: rw dns on"
echo
echo "--- nft marks ---"
nft list ruleset 2>/dev/null | grep -E 'mark_domains|mark_subnet|vpn_domains|vpn_subnets' -n | head -n 80 || true
echo
echo "To capture real TV domains:"
if [ -n "$TV_IP" ]; then
    echo "  tcpdump -i br-lan -n -vvv host $TV_IP and port 53"
else
    echo "  tcpdump -i br-lan -n -vvv host TV_IP and port 53"
fi
