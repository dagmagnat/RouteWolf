#!/bin/sh
/usr/sbin/routewolf-diagnose.sh "$@"
