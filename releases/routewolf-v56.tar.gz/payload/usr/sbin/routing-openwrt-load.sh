#!/bin/sh
exec /usr/sbin/routewolf-load.sh "$@"
