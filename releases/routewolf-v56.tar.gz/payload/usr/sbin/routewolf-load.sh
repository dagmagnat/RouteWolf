#!/bin/sh
# Lightweight resource/load snapshot for weak OpenWrt routers.
echo "=== RouteWolf load check ==="
date 2>/dev/null || true
echo

echo "=== uptime / load average ==="
uptime 2>/dev/null || true
echo

echo "=== memory ==="
free -m 2>/dev/null || free 2>/dev/null || true
echo

echo "=== flash ==="
df -h / /tmp 2>/dev/null || df -h 2>/dev/null || true
echo

echo "=== RouteWolf lists ==="
wc -l /tmp/dnsmasq.d/domains.lst /tmp/lst/ipv4.lst /tmp/lst/ipv6.lst 2>/dev/null || true
ls -lh /tmp/dnsmasq.d/domains.lst /tmp/lst/ipv4.lst /tmp/lst/ipv6.lst 2>/dev/null || true
echo

echo "=== vpn policy route ==="
ip rule show 2>/dev/null | grep -E 'fwmark|lookup vpn' || true
ip route show table vpn 2>/dev/null || true
echo

echo "=== nft counters ==="
nft list ruleset 2>/dev/null | grep -E 'mark_domains|mark_subnet|vpn_domains|vpn_subnets' -n | head -n 40 || true
echo

echo "=== related processes ==="
ps 2>/dev/null | grep -Ei 'dnsmasq|openvpn|awg|wireguard|sing-box|routewolf-route|RouteWolf|routewolf|domain-routing' | grep -v grep || true
echo

echo "=== top snapshot ==="
(top -bn1 2>/dev/null || top -n 1 2>/dev/null) | head -n 20 || true
