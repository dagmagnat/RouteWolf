#!/bin/sh
exec /usr/sbin/routewolf-diagnose.sh "$@"
