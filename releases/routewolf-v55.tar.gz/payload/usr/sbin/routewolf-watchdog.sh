#!/bin/sh

CONF='/etc/routewolf/watchdog.conf'
[ -f "$CONF" ] && . "$CONF"
TYPE="${WATCHDOG_TYPE:-unknown}"
DEV="${WATCHDOG_DEVICE:-}"
UCI_IFACE="${WATCHDOG_UCI_IFACE:-}"
SERVICE="${WATCHDOG_SERVICE:-}"
TEST_URL="${WATCHDOG_URL:-https://www.youtube.com/generate_204}"
LOG_TAG='RouteWolf-watchdog'
LOCK='/tmp/routewolf-watchdog.lock'

log() { logger -t "$LOG_TAG" "$*" 2>/dev/null || echo "$LOG_TAG: $*"; }

lock_or_exit() {
    if mkdir "$LOCK" 2>/dev/null; then
        trap 'rmdir "$LOCK" 2>/dev/null' EXIT INT TERM
    else
        exit 0
    fi
}

fail_open_cleanup() {
    # Never change the main WAN default route. Only clear RouteWolf's policy table.
    ip route del blackhole default table vpn metric 42767 >/dev/null 2>&1 || true
    ip -6 route del blackhole default table vpn metric 42767 >/dev/null 2>&1 || true
    ip route flush table vpn >/dev/null 2>&1 || true
}

route_repair() {
    [ -x /usr/sbin/routewolf-route.sh ] && /usr/sbin/routewolf-route.sh >/dev/null 2>&1 && return 0
    [ -x /usr/sbin/domain-routing-route.sh ] && /usr/sbin/domain-routing-route.sh >/dev/null 2>&1 && return 0
    return 0
}

ensure_boot_enabled() {
    case "$TYPE" in
        wg|awg)
            [ -n "$UCI_IFACE" ] || return 0
            uci set network.$UCI_IFACE.auto='1' 2>/dev/null || true
            uci commit network >/dev/null 2>&1 || true
        ;;
        ovpn) /etc/init.d/openvpn enable >/dev/null 2>&1 || true ;;
        singbox|outline) /etc/init.d/sing-box enable >/dev/null 2>&1 || true ;;
    esac
}

restart_selected() {
    reason="$1"
    log "restart $TYPE/$DEV: $reason"
    fail_open_cleanup
    ensure_boot_enabled

    case "$TYPE" in
        wg|awg)
            ifdown "$UCI_IFACE" >/dev/null 2>&1 || true
            sleep 3
            ifup "$UCI_IFACE" >/dev/null 2>&1 || true
        ;;
        ovpn)
            /etc/init.d/openvpn restart >/dev/null 2>&1 || /etc/init.d/openvpn start >/dev/null 2>&1 || true
        ;;
        singbox|outline)
            /etc/init.d/sing-box restart >/dev/null 2>&1 || /etc/init.d/sing-box start >/dev/null 2>&1 || true
        ;;
    esac

    i=0
    while [ "$i" -lt 25 ]; do
        ip link show dev "$DEV" >/dev/null 2>&1 && ip link show dev "$DEV" 2>/dev/null | grep -q 'UP' && break
        sleep 1
        i=$((i+1))
    done
    route_repair
}

iface_ipv4() {
    ip -4 -o addr show dev "$DEV" 2>/dev/null | awk '{split($4,a,"/"); print a[1]; exit}'
}

check_device() {
    [ -n "$DEV" ] || return 1
    ip link show dev "$DEV" >/dev/null 2>&1 || return 1
    ip link show dev "$DEV" 2>/dev/null | grep -q 'UP' || return 1
    return 0
}

check_connectivity() {
    check_device || return 1
    src="$(iface_ipv4)"

    if command -v curl >/dev/null 2>&1; then
        curl -kfsS --interface "$DEV" --connect-timeout 8 --max-time 15 "$TEST_URL" >/dev/null 2>&1 && return 0
    fi

    if [ -n "$src" ] && command -v wget >/dev/null 2>&1 && wget --help 2>&1 | grep -q -- '--bind-address'; then
        if wget --help 2>&1 | grep -q -- '--no-check-certificate'; then
            wget --no-check-certificate --bind-address="$src" -T 15 -q -O /dev/null "$TEST_URL" >/dev/null 2>&1 && return 0
        else
            wget --bind-address="$src" -T 15 -q -O /dev/null "$TEST_URL" >/dev/null 2>&1 && return 0
        fi
    fi

    ping -I "$DEV" -c 2 -W 4 1.1.1.1 >/dev/null 2>&1 && return 0
    return 1
}

status() {
    echo "=== RouteWolf universal watchdog ==="
    echo "type: $TYPE"
    echo "device: $DEV"
    echo "service: $SERVICE"
    echo "test: $TEST_URL"
    echo "boot service: enabled by installer"
    echo "schedule: every ${WATCHDOG_INTERVAL_MIN:-30} minutes"
    echo "=== interface ==="
    ip addr show dev "$DEV" 2>/dev/null || echo "$DEV not found"
    echo "=== main WAN default (must remain available) ==="
    ip route show default 2>/dev/null || true
    echo "=== RouteWolf vpn table ==="
    ip route show table vpn 2>/dev/null || true
    echo "=== last watchdog log ==="
    logread 2>/dev/null | grep "$LOG_TAG" | tail -n 40 || true
}

run_check() {
    lock_or_exit
    ensure_boot_enabled
    route_repair

    check_connectivity && exit 0
    sleep 10
    check_connectivity && exit 0

    restart_selected 'two connectivity checks failed'
    if check_connectivity; then
        log "recovered: $TYPE/$DEV works after restart"
        exit 0
    fi

    fail_open_cleanup
    route_repair
    log "error: $TYPE/$DEV still unavailable after restart; WAN left in fail-open mode"
    exit 1
}

case "$1" in
    status) status ;;
    restart)
        lock_or_exit
        restart_selected 'manual request'
        status
    ;;
    boot)
        lock_or_exit
        ensure_boot_enabled
        sleep 30
        restart_selected 'router boot recovery'
        check_connectivity || log "boot recovery finished but tunnel test still fails; WAN remains fail-open"
    ;;
    check|test|"") run_check ;;
    *) echo "Usage: $0 [check|status|restart|boot]"; exit 1 ;;
esac
