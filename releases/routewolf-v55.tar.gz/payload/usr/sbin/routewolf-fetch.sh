#!/bin/sh
# Download one HTTPS URL to a file on old and new OpenWrt builds.
url="$1"
out="$2"
[ -n "$url" ] && [ -n "$out" ] || { echo "Usage: $0 URL OUTPUT" >&2; exit 2; }
rm -f "$out"
if [ -x /bin/uclient-fetch ]; then
    /bin/uclient-fetch --no-check-certificate -O "$out" "$url" >/dev/null 2>&1 && [ -s "$out" ] && exit 0
    rm -f "$out"
    /bin/uclient-fetch -O "$out" "$url" && [ -s "$out" ] && exit 0
    rm -f "$out"
fi
if command -v uclient-fetch >/dev/null 2>&1; then
    uclient-fetch --no-check-certificate -O "$out" "$url" >/dev/null 2>&1 && [ -s "$out" ] && exit 0
    rm -f "$out"
    uclient-fetch -O "$out" "$url" && [ -s "$out" ] && exit 0
    rm -f "$out"
fi
if command -v curl >/dev/null 2>&1; then
    curl -kfsSL --connect-timeout 15 --max-time 180 --retry 2 "$url" -o "$out" && [ -s "$out" ] && exit 0
    rm -f "$out"
fi
if command -v wget >/dev/null 2>&1; then
    if wget --help 2>&1 | grep -q -- '--no-check-certificate'; then
        wget --no-check-certificate -O "$out" "$url"
    else
        wget -O "$out" "$url"
    fi
    [ -s "$out" ] && exit 0
fi
rm -f "$out"
echo "No working HTTPS downloader: tried /bin/uclient-fetch, uclient-fetch, curl and wget." >&2
exit 1
