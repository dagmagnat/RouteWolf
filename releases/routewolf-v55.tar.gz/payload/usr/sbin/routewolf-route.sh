#!/bin/sh

# Maintains the separate "vpn" routing table used only by marked traffic.
# Normal, unmarked internet uses the main routing table and is not changed.
# Default safety mode is FAIL-OPEN: if VPN is missing/down, table vpn is left empty
# and Linux policy routing falls back to the main WAN table. This prevents Android/iOS
# from showing "No internet" when connectivity-check domains are in the routing list.
# Leak-protection/fail-closed can be added later as an explicit optional mode.

[ ! -f /etc/routewolf/route.conf ] && [ -f /etc/domain-routing-route.conf ] && { mkdir -p /etc/routewolf; cp /etc/domain-routing-route.conf /etc/routewolf/route.conf 2>/dev/null || true; }
[ ! -f /etc/routewolf/user.conf ] && [ -f /etc/domain-routing-user.conf ] && { mkdir -p /etc/routewolf; cp /etc/domain-routing-user.conf /etc/routewolf/user.conf 2>/dev/null || true; }
[ -f /etc/routewolf/route.conf ] && . /etc/routewolf/route.conf
[ -f /etc/routewolf/user.conf ] && . /etc/routewolf/user.conf
[ -n "$VPN_ROUTE_DEV" ] || exit 0

apply_runtime_mtu() {
    case "${VPN_ROUTE_MTU:-}" in ''|*[!0-9]*) return 0 ;; esac
    [ "$VPN_ROUTE_MTU" -ge 576 ] 2>/dev/null && [ "$VPN_ROUTE_MTU" -le 9000 ] 2>/dev/null || return 0
    ip link show dev "$VPN_ROUTE_DEV" >/dev/null 2>&1 || return 0
    ip link set dev "$VPN_ROUTE_DEV" mtu "$VPN_ROUTE_MTU" >/dev/null 2>&1 || true
}

TABLE="vpn"
grep -q "99 $TABLE" /etc/iproute2/rt_tables 2>/dev/null || echo "99 $TABLE" >> /etc/iproute2/rt_tables

ensure_rule() {
    # Keep exactly one IPv4 rule at priority 100. Older releases sometimes
    # left an auto-priority rule such as "1: fwmark 0x1 lookup vpn".
    ip rule show 2>/dev/null | awk '/fwmark 0x1(\/0x1)?/ && /lookup (vpn|99)/ {gsub(":", "", $1); if ($1 != 100) print $1}' |     while IFS= read -r old_prio; do
        [ -n "$old_prio" ] && ip rule del priority "$old_prio" >/dev/null 2>&1 || true
    done
    if ! ip rule show 2>/dev/null | grep -Eq '^100:.*fwmark 0x1(/0x1)?.*lookup (vpn|99)'; then
        ip rule del fwmark 0x1/0x1 table 99 priority 100 >/dev/null 2>&1 || true
        ip rule add fwmark 0x1/0x1 table 99 priority 100 >/dev/null 2>&1 || return 1
    fi

    if [ "$IPV6_SUPPORT" = "1" ]; then
        ip -6 rule show 2>/dev/null | awk '/fwmark 0x1(\/0x1)?/ && /lookup (vpn|99)/ {gsub(":", "", $1); if ($1 != 100) print $1}' |         while IFS= read -r old_prio; do
            [ -n "$old_prio" ] && ip -6 rule del priority "$old_prio" >/dev/null 2>&1 || true
        done
        if ! ip -6 rule show 2>/dev/null | grep -Eq '^100:.*fwmark 0x1(/0x1)?.*lookup (vpn|99)'; then
            ip -6 rule del fwmark 0x1/0x1 table 99 priority 100 >/dev/null 2>&1 || true
            ip -6 rule add fwmark 0x1/0x1 table 99 priority 100 >/dev/null 2>&1 || return 1
        fi
    fi
    return 0
}

fail_open_route() {
    # Remove stale blackhole or stale VPN default routes from earlier versions.
    ip route del blackhole default table "$TABLE" metric 42767 >/dev/null 2>&1 || true
    ip route del default table "$TABLE" >/dev/null 2>&1 || true
    if [ "$IPV6_SUPPORT" = "1" ]; then
        ip -6 route del blackhole default table "$TABLE" metric 42767 >/dev/null 2>&1 || true
        ip -6 route del default table "$TABLE" >/dev/null 2>&1 || true
    fi
}

remove_openvpn_full_tunnel_routes() {
    case "$VPN_ROUTE_DEV" in
        tun*)
            ip route show 2>/dev/null | grep -E "^(0\.0\.0\.0/1|128\.0\.0\.0/1).* dev ${VPN_ROUTE_DEV}( |$)" | while IFS= read -r route_line; do
                ip route del $route_line >/dev/null 2>&1 || true
            done
        ;;
    esac
}

detect_openvpn_gateway_runtime() {
    dev="$1"
    [ -n "$dev" ] || return 1

    ip route show 0.0.0.0/1 2>/dev/null | awk -v d="$dev" '$2=="via" && $0 ~ " dev " d "( |$)" {print $3; exit}' | grep -m1 . && return 0
    ip route show 128.0.0.0/1 2>/dev/null | awk -v d="$dev" '$2=="via" && $0 ~ " dev " d "( |$)" {print $3; exit}' | grep -m1 . && return 0
    ip route show default 2>/dev/null | awk -v d="$dev" '$2=="via" && $0 ~ " dev " d "( |$)" {print $3; exit}' | grep -m1 . && return 0

    # Preferred fallback: first host of the current connected tun subnet.
    # This avoids stale gateways after OpenVPN reconnects into another pool
    # (e.g. 10.28.0.3/22 -> 10.28.4.5/22 means gateway must become 10.28.4.1).
    ip -4 route show dev "$dev" scope link 2>/dev/null | awk 'NR==1 {split($1,n,"/"); split(n[1],o,"."); if (o[1] != "" && o[2] != "" && o[3] != "") {print o[1]"."o[2]"."o[3]"."(o[4]+1); exit}}' | grep -m1 . && return 0

    ip -4 addr show dev "$dev" 2>/dev/null | awk '/ inet / {split($2,a,"/"); split(a[1],o,"."); if (o[1] != "" && o[2] != "" && o[3] != "") {print o[1]"."o[2]"."o[3]".1"; exit}}'
}

persist_openvpn_gateway_runtime() {
    dev="$1"
    gw="$2"
    [ -n "$dev" ] || return 0
    [ -n "$gw" ] || return 0
    conf="/etc/routewolf/route.conf"
    tmp="/tmp/routewolf-route.conf.$$"
    {
        echo "VPN_ROUTE_DEV='$dev'"
        echo "VPN_ROUTE_GW='$gw'"
        if [ -f "$conf" ]; then
            grep -v -E '^(VPN_ROUTE_DEV|VPN_ROUTE_GW)=' "$conf" 2>/dev/null || true
        fi
    } > "$tmp"
    mv "$tmp" "$conf" 2>/dev/null || true
}

use_vpn_route() {
    # Always remove the old fail-closed blackhole before installing a working VPN route.
    ip route del blackhole default table "$TABLE" metric 42767 >/dev/null 2>&1 || true
    remove_openvpn_full_tunnel_routes

    case "$VPN_ROUTE_DEV" in
        tun*)
            # Re-detect every run. OpenVPN may reconnect and receive a different
            # tun subnet/gateway; a stale VPN_ROUTE_GW breaks policy routing.
            RUNTIME_GW="$(detect_openvpn_gateway_runtime "$VPN_ROUTE_DEV" | head -n 1)"
            GW="${RUNTIME_GW:-${VPN_ROUTE_GW:-}}"

            if [ -n "$GW" ] && ip route replace default via "$GW" dev "$VPN_ROUTE_DEV" table "$TABLE" metric 10 >/dev/null 2>&1; then
                [ "$GW" = "$VPN_ROUTE_GW" ] || persist_openvpn_gateway_runtime "$VPN_ROUTE_DEV" "$GW"
            elif ip link show dev "$VPN_ROUTE_DEV" 2>/dev/null | grep -q POINTOPOINT; then
                # No gateway could be determined, but the device is point-to-point.
                # A next hop is NOT required on a NOARP p2p link: "default dev tunX"
                # is exactly what we already do for wg/awg below, and it is correct.
                # Failing open here was the old bug: OpenVPN "dev tun" almost always
                # lands in this branch, so the vpn table was wiped and nothing routed.
                ip route replace default dev "$VPN_ROUTE_DEV" table "$TABLE" scope link metric 10 >/dev/null 2>&1 || {
                    ip route del default table "$TABLE" >/dev/null 2>&1 || true
                    return 1
                }
            else
                # Genuinely ambiguous: no gateway AND not point-to-point. Fail open.
                ip route del default table "$TABLE" >/dev/null 2>&1 || true
                return 1
            fi
        ;;
        *)
            ip route replace default dev "$VPN_ROUTE_DEV" table "$TABLE" scope link metric 10 >/dev/null 2>&1 || return 1
        ;;
    esac

    if [ "$IPV6_SUPPORT" = "1" ]; then
        ip -6 route del blackhole default table "$TABLE" metric 42767 >/dev/null 2>&1 || true
        ip -6 route replace default dev "$VPN_ROUTE_DEV" table "$TABLE" metric 10 >/dev/null 2>&1 || true
    fi
    return 0
}

ensure_rule
apply_runtime_mtu

i=0
while [ "$i" -lt 30 ]; do
    if ip link show dev "$VPN_ROUTE_DEV" >/dev/null 2>&1; then
        if ip link show dev "$VPN_ROUTE_DEV" | grep -q "UP"; then
            use_vpn_route && exit 0
        fi
    fi
    i=$((i + 1))
    sleep 1
done

fail_open_route
exit 0
